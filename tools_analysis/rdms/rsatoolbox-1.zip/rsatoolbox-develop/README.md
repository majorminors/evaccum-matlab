# rsatoolbox
A Matlab toolbox for representational similarity analysis
